from langchain.schema import HumanMessage,SystemMessage
from langchain_openai import OpenAI,ChatOpenAI
from langchain.prompts import PromptTemplate,ChatPromptTemplate,HumanMessagePromptTemplate,SystemMessagePromptTemplate
from embedding import Zhipuembedding,OpenAIembedding,HFembedding,Jinaembedding
from data_chunker import ReadFile
from databases import Vectordatabase
import os
import json
from typing import Dict, List, Optional, Tuple, Union
import PyPDF2
import httpx


#把api_key放在环境变量中,可以在系统环境变量中设置，也可以在代码中设置
# import os
# os.environ['OPENAI_API_KEY'] = ''
import os

class Openai_model:
    def __init__(self,model_name:str="glm-4",temperature:float=0.9,) -> None:
        self.history_cnt = 1
        #初始化大模型
        self.model_name=model_name
        self.temperature=temperature
        self.model=ChatOpenAI(
                                    temperature=temperature,
                                    model="glm-4",
                                    openai_api_key="16a07a83159b1531481329b6ea8e7f9e.TZ5TQiK48wr3iVP3",
                                    openai_api_base="https://open.bigmodel.cn/api/paas/v4/"
                                )

        #加载向量数据库，embedding模型
        self.db=Vectordatabase()
        self.db.load_vector()
        self.embedding_model=Zhipuembedding()


        #将对话问题写入chat_history文件中
    def chat_persist(self,human_content:str,path:str='database'):
        if not os.path.exists(path):
            os.makedirs(path)

        with open(f"{path}/chat_history.json", "r", encoding="utf-8") as f:
            try:
                old_conv = json.load(f)
            except:
                old_conv = {}
            old_conv.update({f"{self.history_cnt}-human_message":human_content})
            self.history_cnt += 1
        with open(f"{path}/chat_history.json", "w", encoding="utf-8") as f:
            json.dump(old_conv,f,ensure_ascii=False)


    def question_concat(self,question:str):
        #这里利用输入的问题与向量数据库里的相似度来匹配最相关的信息，填充到输入的提示词中
        template="""
        请你按以下流程回答问题：
        1.判断问题中是否有存在歧义的部分
        2.如果不存在有歧义的部分，原封不动的返回问题。如果存在有歧义的部分，尝试结合对话历史搞清楚问题，返回理解后的问题
        如果你无论如何都无法理解问题，原封不动的返回问题。
        3.请最简明扼要的返回问题的内容
        问题: {question}
        对话历史：{history}
        有用的回答:"""


        with open("database/chat_history.json", "r", encoding="utf-8") as f:
            try:
                history = json.load(f)
            except:
                history = None
            f.close()

        prompt=PromptTemplate(template=template,input_variables=["question","history"]).format(question=question,history=history)

        # 会话历史


        res=self.model.invoke(prompt).content
        self.chat_persist(human_content=question)

        return  res


    def chat(self,question:str):
        #这里利用输入的问题与向量数据库里的相似度来匹配最相关的信息，填充到输入的提示词中
        template="""
        假设你是一个水利领域的专家
        如果有必要，你可以结合上下文回答问题，
        请记住，上下文是可参考，不是一定要参考如果你认为不需要参考上下文，请自由回答。
        如果你不知道答案，就说你不知道。如果给定的上下文无法让你做出回答，请回答数据库中没有这个内容，你不知道。
        问题: {question}
        ························
        可参考的上下文：
        ···
        {info}
        ···
        有用的回答:"""



        info=self.db.query(question,self.embedding_model,10)
        prompt=PromptTemplate(template=template,input_variables=["question","info","history"]).format(question=question,info=info)

        # 会话历史


        res=self.model.invoke(prompt).content

        return  res





