from embedding import Zhipuembedding,OpenAIembedding,HFembedding,Jinaembedding
from data_chunker import ReadFile
from databases import Vectordatabase
import os
import json
from typing import Dict, List, Optional, Tuple, Union
import PyPDF2

import gradio as gr
from llms import Openai_model
import time



# #建立数据库
# filter=ReadFile('./data')
# docs=filter.get_all_chunk_content(600,100)
# embedding_model=Zhipuembedding()
# database=Vectordatabase(docs)
# Vectors=database.get_vector(embedding_model)
# database.persist()
# #将向量和文档内容保存到db目录下，下次再用就可以直接加载本地的数据库
# # 加载向量数据库
# text="pytorch"
# embedding_model=Zhipuembedding()
# db=Vectordatabase()
# db.load_vector('database')
# result=db.query(text,embedding_model,10)
# print(result)


# def echo(message, history):
#     result=model.chat(message)
#     for i in range(len(result)):
#         time.sleep(0.02)
#         yield result[:i+1]


model = Openai_model()
def answer(question):
    question_new =model.question_concat(question)
    result= model.chat(question_new)
    for i in range(len(result)):
        time.sleep(0.02)
        print(result[i:i+1],end='')
    print()


with open ("database/chat_history.json","w",encoding="utf-8") as f:
    f.write("")
while True:
    question = input("请输入question:")
    if question =='end':
        break
    answer(question)

print("回答结束~~")
#自定义的流式输出







# demo = gr.ChatInterface(fn=echo,
#                         examples=["中华人民共和国消费者权益保护法什么时候,在哪个会议上通过的？", "中华人民共和国消费者权益保护的目录是什么？","RinyRAG的项目结构是怎么样的"],
#                         title="Echo Bot",
#                         theme="soft",
#                         type='messages')
# demo.launch(share=True)